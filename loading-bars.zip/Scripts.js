function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
  }
  
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
$(document).ready(function () {
    var d = new Date();
    var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

   
    var datTimes = months[d.getMonth] + ' ' + d.getDate + ',' + d.getFullYear + ' ' + d.getHours + ':' + d.getMinutes;
   // alert(datTime);
   // document.getElementById("demo").innerHTML = datTimes;
    $("#menu-toggle").click(function (e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });

});